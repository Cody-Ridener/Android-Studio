package com.example.cmridenewishlistresturaunt;

import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;

import com.example.cmridenewishlistresturaunt.ui.main.SectionsPagerAdapter;
import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {
    //Variables we're going to use to create our map later.
    private MapView mapView;
    private GoogleMap map;
    Bundle info;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        info = savedInstanceState;
        setContentView(R.layout.activity_main);
        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());
        setupAdapter(sectionsPagerAdapter);
        ViewPager viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(sectionsPagerAdapter);
       TabLayout tabs = findViewById(R.id.tabs);
       tabs.setupWithViewPager(viewPager);
        FloatingActionButton fab = findViewById(R.id.fab);
        mapView = findViewById(R.id.mapView);
        if(mapView !=null) {
            mapView.onCreate(savedInstanceState);
            mapView.getMapAsync(this);
        }
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

    }
    private void setupAdapter(SectionsPagerAdapter sp){
        sp.addFragment(new MapPoiFrag(), "Map");
        sp.addFragment(new favoritesList(), "Favorites");

    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;
    }

    public void addToFavorites(View view) {
        SharedPreferences pref = this.getSharedPreferences("Current", this.MODE_PRIVATE);
        addToPreferences(pref.getString("Current","None"));
        Button btn = this.findViewById(R.id.btnFav);
        btn.setText("Favorited");


    }
    public void addToPreferences(String s){
        SharedPreferences pref = this.getSharedPreferences("Favorites", this.MODE_APPEND);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(s,s);
        editor.commit();
    }
}